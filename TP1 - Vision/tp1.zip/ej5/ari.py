


img_2 = cv2.resize(img_2, dim, interpolation=cv2.INTER_AREA)